﻿namespace WFA_CW_DC_SP_TESTER
{
    partial class mainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainForm));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileSubmenu = new System.Windows.Forms.ToolStripMenuItem();
            this.instrumentSubmenu = new System.Windows.Forms.ToolStripMenuItem();
            this.proberSubmenu = new System.Windows.Forms.ToolStripMenuItem();
            this.DUTSubmenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolSubmenu = new System.Windows.Forms.ToolStripMenuItem();
            this.helpSubmenu = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutSubmenu = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.BackColor = System.Drawing.SystemColors.Info;
            this.menuStrip.GripMargin = new System.Windows.Forms.Padding(2, 10, 0, 10);
            this.menuStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip.ImageScalingSize = new System.Drawing.Size(30, 30);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileSubmenu,
            this.instrumentSubmenu,
            this.proberSubmenu,
            this.DUTSubmenu,
            this.toolSubmenu,
            this.helpSubmenu,
            this.aboutSubmenu});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Margin = new System.Windows.Forms.Padding(0, 10, 0, 10);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(2226, 48);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "menuStrip1";
            // 
            // fileSubmenu
            // 
            this.fileSubmenu.Image = global::WFA_CW_DC_SP_TESTER.Properties.Resources.folder;
            this.fileSubmenu.Name = "fileSubmenu";
            this.fileSubmenu.Padding = new System.Windows.Forms.Padding(50, 0, 20, 0);
            this.fileSubmenu.Size = new System.Drawing.Size(154, 44);
            this.fileSubmenu.Text = "File";
            // 
            // instrumentSubmenu
            // 
            this.instrumentSubmenu.Image = global::WFA_CW_DC_SP_TESTER.Properties.Resources.oscilloscope;
            this.instrumentSubmenu.Name = "instrumentSubmenu";
            this.instrumentSubmenu.Padding = new System.Windows.Forms.Padding(30, 0, 4, 0);
            this.instrumentSubmenu.Size = new System.Drawing.Size(182, 44);
            this.instrumentSubmenu.Text = "Instrument";
            // 
            // proberSubmenu
            // 
            this.proberSubmenu.Image = global::WFA_CW_DC_SP_TESTER.Properties.Resources.wafer;
            this.proberSubmenu.Name = "proberSubmenu";
            this.proberSubmenu.Padding = new System.Windows.Forms.Padding(30, 0, 4, 0);
            this.proberSubmenu.Size = new System.Drawing.Size(146, 44);
            this.proberSubmenu.Text = "Prober";
            // 
            // DUTSubmenu
            // 
            this.DUTSubmenu.Image = global::WFA_CW_DC_SP_TESTER.Properties.Resources.MOS;
            this.DUTSubmenu.Name = "DUTSubmenu";
            this.DUTSubmenu.Padding = new System.Windows.Forms.Padding(30, 0, 4, 0);
            this.DUTSubmenu.Size = new System.Drawing.Size(125, 44);
            this.DUTSubmenu.Text = "DUT";
            // 
            // toolSubmenu
            // 
            this.toolSubmenu.Image = global::WFA_CW_DC_SP_TESTER.Properties.Resources.tool_box;
            this.toolSubmenu.Name = "toolSubmenu";
            this.toolSubmenu.Padding = new System.Windows.Forms.Padding(30, 0, 4, 0);
            this.toolSubmenu.Size = new System.Drawing.Size(125, 44);
            this.toolSubmenu.Text = "Tool";
            // 
            // helpSubmenu
            // 
            this.helpSubmenu.Image = global::WFA_CW_DC_SP_TESTER.Properties.Resources.help;
            this.helpSubmenu.Name = "helpSubmenu";
            this.helpSubmenu.Padding = new System.Windows.Forms.Padding(30, 0, 4, 0);
            this.helpSubmenu.Size = new System.Drawing.Size(129, 44);
            this.helpSubmenu.Text = "Help";
            // 
            // aboutSubmenu
            // 
            this.aboutSubmenu.Image = global::WFA_CW_DC_SP_TESTER.Properties.Resources.about;
            this.aboutSubmenu.Name = "aboutSubmenu";
            this.aboutSubmenu.Padding = new System.Windows.Forms.Padding(30, 0, 4, 0);
            this.aboutSubmenu.Size = new System.Drawing.Size(142, 44);
            this.aboutSubmenu.Text = "About";
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2226, 1410);
            this.Controls.Add(this.menuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip;
            this.Name = "mainForm";
            this.Text = " Terahertz-Detector";
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileSubmenu;
        private System.Windows.Forms.ToolStripMenuItem instrumentSubmenu;
        private System.Windows.Forms.ToolStripMenuItem proberSubmenu;
        private System.Windows.Forms.ToolStripMenuItem DUTSubmenu;
        private System.Windows.Forms.ToolStripMenuItem toolSubmenu;
        private System.Windows.Forms.ToolStripMenuItem helpSubmenu;
        private System.Windows.Forms.ToolStripMenuItem aboutSubmenu;
    }
}

